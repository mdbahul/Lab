package com.example.geocamerax;

import android.Manifest;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    PreviewView previewView;
    Button captureBtn;
    TextView locationText;

    ImageCapture imageCapture;

    FusedLocationProviderClient fusedLocationClient;

    double lat = 0;
    double lon = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.previewView);
        captureBtn = findViewById(R.id.captureBtn);
        locationText = findViewById(R.id.locationText);

        ActivityCompat.requestPermissions(this,
                new String[]{
                        Manifest.permission.CAMERA,
                        Manifest.permission.ACCESS_FINE_LOCATION
                },1);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        startCamera();
        updateLocation();

        captureBtn.setOnClickListener(v -> capturePhoto());
    }

    private void startCamera() {

        ListenableFuture<ProcessCameraProvider> cameraProviderFuture =
                ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {

            try {

                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                imageCapture = new ImageCapture.Builder().build();

                cameraProvider.unbindAll();

                cameraProvider.bindToLifecycle(
                        this,
                        androidx.camera.core.CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        imageCapture
                );

            } catch (ExecutionException | InterruptedException e) {
                e.printStackTrace();
            }

        }, getMainExecutor());
    }

    private void updateLocation(){

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(location -> {

                    if(location != null){

                        lat = location.getLatitude();
                        lon = location.getLongitude();

                        locationText.setText(
                                "Lat: " + lat + "\nLon: " + lon
                        );
                    }

                });
    }

    Bitmap addLocationStamp(Bitmap original){
        Bitmap mutableBitmap =
                original.copy(Bitmap.Config.ARGB_8888, true);

        Canvas canvas = new Canvas(mutableBitmap);

        Paint paint = new Paint();
        paint.setColor(android.graphics.Color.WHITE);
        paint.setTextSize(60);
        paint.setAntiAlias(true);

        String text = "Lat: " + lat + "  Lon: " + lon;

        canvas.drawText(text, 50,
                mutableBitmap.getHeight() - 50,
                paint);

        return mutableBitmap;
    }

    private void capturePhoto(){

        File file = new File(getExternalMediaDirs()[0],
                System.currentTimeMillis() + ".jpg");

        ImageCapture.OutputFileOptions options =
                new ImageCapture.OutputFileOptions.Builder(file).build();

        imageCapture.takePicture(
                options,
                getMainExecutor(),
                new ImageCapture.OnImageSavedCallback() {

                    Bitmap stampedImage = addLocationStamp(bitmap);

                    @Override
                    public void onImageSaved(ImageCapture.OutputFileResults outputFileResults) {

                        locationText.setText("Saved with location!");
                    }

                    @Override
                    public void onError(ImageCaptureException exception) {

                        exception.printStackTrace();
                    }
                });
    }
}